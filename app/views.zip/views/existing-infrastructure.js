"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var existing_infrastructure_service_1 = require("../services/existing-infrastructure-service");
var _ = require("lodash");
var ExistingInfrastructureView = (function () {
    function ExistingInfrastructureView(existingInfrastructureService) {
        this.existingInfrastructureService = existingInfrastructureService;
        this.showModal = false;
        this.viewDetailsFor = null;
    }
    ExistingInfrastructureView.prototype.ngOnInit = function () {
        var _this = this;
        this.existingInfrastructureService.getExistingInfra().subscribe(function (data) {
            _this.existingInfraList = data;
        }, function () { return console.log('Finished'); });
    };
    ExistingInfrastructureView.prototype.viewDetails = function (cloudId) {
        this.showModal = true;
        this.viewDetailsFor = _.find(this.existingInfraList, { 'cloud_id': cloudId });
    };
    ExistingInfrastructureView.prototype.hideModal = function () {
        this.showModal = false;
        this.viewDetailsFor = null;
    };
    return ExistingInfrastructureView;
}());
ExistingInfrastructureView = __decorate([
    core_1.Component({
        providers: [existing_infrastructure_service_1.ExistingInfrastructureService],
        template: "<div id=\"breadcrumb\" class=\"col-md-12\">\n                <ol class=\"breadcrumb\">\n                    <li><a href=\"index.html\">Home</a></li>\n                    <li><a href=\"#\">Orchestration</a></li>\n                    <li><a href=\"#\">Infrastructure</a></li>\n                    <li><a href=\"#\">Existing Infrastructure</a></li>\n                  </ol>\n              </div>\n              <div id=\"new-deployment-header\" class=\"row\">\n                <div class=\"col-xs-12\">\n                  <h4>Existing Infrastructure</h4>\n                </div>\n              </div>\n              <div>\n                <div class=\"box-content no-padding table-responsive\">\n                 <table class=\"table table-bordered table-striped table-hover table-heading table-datatable dataTable\" >\n                   <thead>\n                        <tr>\n                          <th>CloudID</th>\n                          <th>Cloud Type</th>\n                          <th>Provider</th>\n                          <th>Request Name</th>\n                          <th>Status</th>\n                          <th>Timestamp</th>\n                        </tr>\n                    </thead>\n                    <tfoot>\n                          <tr>\n                          <th>CloudID</th>\n                          <th>Cloud Type</th>\n                          <th>Provider</th>\n                          <th>Request Name</th>\n                          <th>Status</th>\n                          <th>Timestamp</th>\n                        </tr>\n                    </tfoot>\n                    <tbody>\n                      <tr *ngFor=\"let existingInfra of existingInfraList\">\n                          <td><a (click)=\"viewDetails(existingInfra.cloud_id)\">{{existingInfra.cloud_id}}</a></td>\n                          <td>{{existingInfra.cloud_type}}</td>\n                          <td>{{existingInfra.provider}}</td>\n                          <td>{{existingInfra.req_name}}</td>\n                          <td>{{existingInfra.status}}</td>\n                          <td>{{existingInfra.timestamp}}</td>\n                      </tr>\n                    </tbody>\n                    </table>\n                     <div class=\"box-content\">\n                      <div class=\"col-sm-6\">\n                       <div class=\"dataTables_info\" id=\"datatable-3_info\">Showing 1 to 20 entries</div></div>\n                         <div class=\"col-sm-6 text-right\">\n                          <div class=\"dataTables_paginate paging_bootstrap\">\n                            <ul class=\"pagination\">\n                            <li class=\"prev disabled\"><a href=\"#\">\u2190 Previous</a></li>\n                            <li class=\"active\"><a href=\"#\">1</a></li>\n                            <li class=\"next disabled\"><a href=\"#\">Next \u2192 </a></li>\n                            </ul>\n                          </div>\n                         </div>\n                         <div class=\"clearfix\">\n                         </div>\n                       </div>\n                  </div>\n              </div>\n              <div class=\"modal\" style=\"margin-top: 60px\" \n              [ngClass]=\"{'show': showModal}\" id=\"myModal\" role=\"dialog\">\n                <div class=\"modal-dialog\" role=\"document\">\n                  <div class=\"modal-content\">\n                    <div class=\"modal-header\">\n                      <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\" (click)=\"hideModal()\">\n                      <span aria-hidden=\"true\">&times;</span></button>\n                      <h4 class=\"modal-title\" id=\"myModalLabel\">Cloud Details</h4>\n                    </div>\n                    <div class=\"modal-body\">\n                      <div *ngIf=\"viewDetailsFor\">\n                          Cloud ID is {{viewDetailsFor.cloud_id}}<br/>\n                          Cloud Type is {{viewDetailsFor.cloud_type}}<br/>\n                          Request Name is {{viewDetailsFor.req_name}}<br/>\n                          Provider is {{viewDetailsFor.provider}}<br/>\n                          Status says {{viewDetailsFor.status}}<br/>\n                          Timestamp recorded: {{viewDetailsFor.time_stamp}}<br/>\n                      </div>\n                    </div>\n                    <div class=\"modal-footer\">\n                      <button type=\"button\" class=\"btn btn-primary\" data-dismiss=\"modal\" (click)=\"hideModal()\">Close</button>\n                    </div>\n                  </div>\n                </div>\n              </div>"
    }),
    __metadata("design:paramtypes", [existing_infrastructure_service_1.ExistingInfrastructureService])
], ExistingInfrastructureView);
exports.ExistingInfrastructureView = ExistingInfrastructureView;
//# sourceMappingURL=existing-infrastructure.js.map