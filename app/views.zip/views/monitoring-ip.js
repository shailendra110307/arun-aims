"use strict";
/**
 * Created by Rini Daniel on 2/2/2017.
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var monitoringIP_model_1 = require("../model/monitoringIP-model");
var router_1 = require("@angular/router");
var monitoringIP_service_1 = require("../services/monitoringIP-service");
var Observable_1 = require("rxjs/Observable");
var _ = require("lodash");
var IPMonitoringView = (function () {
    function IPMonitoringView(router, route, monitoringIPService, ref) {
        var _this = this;
        this.router = router;
        this.monitoringIPService = monitoringIPService;
        this.ref = ref;
        this.host = route.snapshot.params['host'];
        this.monitoringIp = new monitoringIP_model_1.MonitoringIP();
        this.isWidget = false;
        router.events.subscribe(function (val) {
            if (val instanceof router_1.NavigationEnd) {
                if (_.startsWith(val.url, '/widget')) {
                    _this.isWidget = true;
                }
                else {
                    _this.isWidget = false;
                }
            }
        });
    }
    IPMonitoringView.prototype.ngOnInit = function () {
        var _this = this;
        this.timer = Observable_1.Observable.timer(0, 2000);
        this.subscription = this.timer.subscribe(function () {
            _this.monitoringIPService.getIPDetails(_this.host).subscribe(function (data) {
                _this.monitoringIp.setData(data.result.values);
                _this.ref.detectChanges();
            }, function () { return console.log('Finished'); });
        });
    };
    IPMonitoringView.prototype.ngOnDestroy = function () {
        if (this.subscription && this.subscription.unsubscribe) {
            this.subscription.unsubscribe();
        }
    };
    return IPMonitoringView;
}());
IPMonitoringView = __decorate([
    core_1.Component({
        providers: [monitoringIP_service_1.MonitoringIPService],
        template: "<div class=\"container\">\n              <div class=\"row\">\n                <div id=\"breadcrumb\" class=\"col-md-12\">\n                  <ol class=\"breadcrumb\">\n                    <li><a [routerLink]=\"(isWidget ? '/widget-monitoring' : '/dashboard')\">Home</a></li>\n                    <li><a [routerLink]=\"(isWidget ? '/widget-monitoring' : '/monitoring')\">Monitoring</a></li>\n                    <li><a href=\"Javascript:void(0)\">Server Monitoring</a></li>\n                  </ol>\n                </div>\n             </div>\n             <div class=\"row\">\n                      <div class=\"col-md-12\">\n                          <div class=\"col-md-2\">\n                                  <div class=\"x_panel\">\n                                        <div class=\"x_title\">\n                                            <h2 class=\"container monitoring_center\">Server Information</h2>\n                                            <div class=\"clearfix\"></div>\n                                        </div>\n                                        <div class=\"x_content\">\n                                              <p>Server Status: Active</p>\n                                              <p>Node: Jump Host</p>\n                                              <p>Public IP: 192.168.20.137</p>\n                                              <p>Private IP: 192.168.1.20</p>\n                                              <p>FQDN: deployment.cnet.com</p>\n                                              <p>Domain Name:\tcnet.com</p>\n                                              <p>Operating System:\tUbuntu 14.04</p>\n                                              <p>Data Center:\tDallas</p>\n                                              <p>Provider:\tBaremetal</p>\n                                              <p>Project:</p>\n                                              <p>Role: Deployment Server</p>\n                                        </div>\n                                    </div>\n                                    <div class=\"x_panel\">\n                                        <div class=\"x_title\">\n                                        <h2 class=\"container monitoring_center\">Server Facts</h2>\n                                        <div class=\"clearfix\"></div>\n                                        </div>\n                                        <div class=\"x_content\">\n                                        <p>Active Users: 10</p>\n                                        <p>Processes running: 19</p>\n                                        <p>Status: Active</p>\n                                        <p>ACtive Since: 135 days</p>\n                                        <p>Average CPU Utilisation: 2.304%</p>\n                                        <p>Average Memory Utilisation: 2.5765GB</p>\n                                        </div>\n                                    </div>\n                            </div>\n                       \n                            <div class=\"col-md-6 charts\">\n                                <div class=\"x_panel\">\n                                                <area-chart-old  title=\"CPU Utilization\" seriesTitle=\"CPU Utilization\" max = \"100\"\n                                                [series]=\"[{name:'Idle time', data: this.monitoringIp.cpuUtilisationIdle},\n                                                {name:'User', data: this.monitoringIp.cpuUtilisationUser}, \n                                                {name:'System', data: this.monitoringIp.cpuUtilisationSystem},\n                                                {name:'IOWait', data: this.monitoringIp.cpuUtilisationIOWait}, \n                                                {name:'Nice Time', data: this.monitoringIp.cpuUtilisationNiceTime}]\" \n                                                height = \"200\" width=\"300\">\n                                                  </area-chart-old>\n                                </div>\n                                <div class=\"x_panel\">\n                                              <line-chart-d3  title=\"Network Traffic\" seriesTitle=\"Network Traffic\" \n                                              [series]=\"[{name:'input traffic', data: this.monitoringIp.inputNetworkTraffic}, \n                                              {name:'output traffic', data: this.monitoringIp.outputNetworkTraffic}]\" \n                                              height = \"200\" width=\"300\" >\n                                                </line-chart-d3>\n                                </div>\n                                <div class=\"x_panel\">\n                                          <area-chart-old  title=\"Memory Usage\" seriesTitle=\"Memory Usage\" \n                                          [series]=\"[{name:'Memory Usage', data: this.monitoringIp.memoryUsage}]\" \n                                          height = \"200\" width=\"300\">\n                                            </area-chart-old>\n                                </div>\n                            </div>\n                            \n                            <div class=\"col-md-4\">\n                                 <div class=\"x_panel\">\n                                    <div class=\"x_title\">\n                                    <h2 class=\"container monitoring_center\">Disk Utlisation</h2>\n                                    <div class=\"clearfix\"></div>\n                                    </div>\n                                    <div class=\"x_content\">\n                                    <p>Disk Used: 40%</p>\n                                    </div>\n                                </div>\n                                <div class=\"x_panel\">\n                                    <div class=\"x_title\">\n                                    <h2 class=\"container monitoring_center\">List of Applications</h2>\n                                    <div class=\"clearfix\"></div>\n                                    </div>\n                                    <div class=\"x_content\">\n                                          <table class=\"table table-bordered table-striped\" >\n                                              <thead>\n                                                    <tr>\n                                                      <th>Name</th>\n                                                      <th>Total</th>\n                                                      <th>Available</th>\n                                                    </tr>\n                                                </thead>\n                                                <tbody>\n                                                  <tr>\n                                                      <td>/dev/disk1</td>\n                                                      <td>10</td>\n                                                      <td>5</td>\n                                                  </tr>\n                                                  </tbody>\n                                            </table>\n                                    </div>\n                              </div>\n                              <div class=\"x_panel\">\n                              <d3-area-chart></d3-area-chart>\n                              </div>\n                          </div>\n                    </div>\n             </div> "
    }),
    __metadata("design:paramtypes", [router_1.Router, router_1.ActivatedRoute, monitoringIP_service_1.MonitoringIPService,
        core_1.ChangeDetectorRef])
], IPMonitoringView);
exports.IPMonitoringView = IPMonitoringView;
//# sourceMappingURL=monitoring-ip.js.map