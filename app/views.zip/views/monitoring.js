"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var alertSummary_service_1 = require("../services/alertSummary-service");
var router_1 = require("@angular/router");
var _ = require("lodash");
var MonitoringView = (function () {
    function MonitoringView(router, alertSummaryService, ref) {
        var _this = this;
        this.router = router;
        this.alertSummaryService = alertSummaryService;
        this.ref = ref;
        this.isWidget = false;
        this.pageIndex = 1;
        this.itemsPerPage = 5;
        router.events.subscribe(function (val) {
            if (val instanceof router_1.NavigationEnd) {
                if (_.startsWith(val.url, '/widget')) {
                    _this.isWidget = true;
                }
                else {
                    _this.isWidget = false;
                }
            }
        });
    }
    MonitoringView.prototype.onPageChange = function (newIndex) {
        this.pageIndex = newIndex;
        this.alertList = this.createPageChunk(this.initialAlertList);
    };
    MonitoringView.prototype.callAlerts = function () {
        var _this = this;
        this.alertSummaryService.getAlertSummary().subscribe(function (data) {
            _this.pageIndex = 1;
            _this.initialAlertList = data;
            _this.alertList = _this.createPageChunk(data);
        }, function () { return console.log('Finished'); });
    };
    MonitoringView.prototype.createPageChunk = function (data) {
        this.totalPages = _.ceil(data.length / this.itemsPerPage);
        return _.chunk(data || [], this.itemsPerPage)[this.pageIndex - 1];
    };
    MonitoringView.prototype.onIPChange = function (filteredIPs) {
        this.pageIndex = 1;
        if (filteredIPs === undefined) {
            this.alertList = this.createPageChunk(this.initialAlertList);
        }
        else {
            this.alertList = this.createPageChunk(_.filter(this.initialAlertList || [], function (alert) {
                return _.includes(filteredIPs, alert.ip_address);
            }));
        }
    };
    MonitoringView.prototype.ngOnInit = function () {
        this.callAlerts();
    };
    return MonitoringView;
}());
MonitoringView = __decorate([
    core_1.Component({
        providers: [
            alertSummary_service_1.AlertSummaryService
        ],
        template: "<div class=\"row\">\n                <div id=\"breadcrumb\" class=\"col-md-12\">\n                  <ol class=\"breadcrumb\">\n                    <li><a [routerLink]=\"(isWidget ? '/widget-monitoring' : '/dashboard')\">Home</a></li>\n                    <li><a [routerLink]=\"(isWidget ? '/widget-monitoring' : '/monitoring')\">Monitoring</a></li>\n                  </ol>\n                </div>\n             </div>\n             <monitoring-graphs (onIPChange)=\"this.onIPChange($event.filteredIPs)\"></monitoring-graphs>\n            <div id=\"new-deployment-header\" class=\"row\">\n                <div class=\"col-md-12\">\n                  <h4>Alert Summary:</h4>\n                </div>\n            </div>\n              <div>\n                <div class=\"box-content no-padding table-responsive\">\n                 <table class=\"table table-bordered table-striped table-hover table-heading table-datatable dataTable\" >\n                   <thead>\n                        <tr>\n                          <th>IP Address / Host</th>\n                          <th>Description</th>\n                           <th>Severity</th>\n                            <th>Time Stamp</th>\n                             <th>Status</th>\n                          <th>Age</th>\n                        </tr>\n                    </thead>\n                     <tbody>\n                      <tr *ngFor=\"let alert of alertList\">\n                          <td><a \n                          [routerLink]=\"(isWidget ? '/widget-monitoring/' : '/monitoring/')+(alert.ip_address || alert.host)\">\n                          <u>{{alert.ip_address || alert.host}}</u></a></td>\n                          <td><a\n                          [routerLink]=\"(isWidget ? '/widget-log-insight/' : '/log-insight/')+\n                          (alert.ip_address || alert.host) + '/' +alert.time_stamp + '/' +alert.error_details\"><u>\n                          {{alert.error_details}}</u></a></td>\n                          <td>{{alert.severity}}</td>\n                          <td>{{alert.time_stamp}}</td>\n                          <td>{{alert.status}}</td>\n                          <td>{{alert.age}}</td>\n                          </tr>\n                    </tbody>\n                   </table>\n                  </div>\n              </div>\n              <div class=\"box-content\">\n                      <div class=\"col-sm-6\">\n                       <div class=\"dataTables_info\" id=\"datatable-3_info\">\n                       Showing \n                       {{((pageIndex-1)*itemsPerPage)+1}}\n                        to \n                        {{((pageIndex-1)*itemsPerPage)+(alertList &&alertList.length || 0)}}\n                         alerts</div></div>\n                         <div class=\"col-sm-6 text-right\">\n                          <div class=\"dataTables_paginate paging_bootstrap\">\n                            <ul class=\"pagination\">\n                            <li class=\"prev\" [ngClass]=\"{'disabled': pageIndex === 1}\">\n                            <a (click)=\"pageIndex > 1 && this.onPageChange(pageIndex-1)\">\u2190 Previous</a></li>\n                            <li class=\"active\"><a>{{pageIndex}}</a></li>\n                            <li class=\"next\" [ngClass]=\"{'disabled': pageIndex === totalPages}\">\n                            <a (click)=\"pageIndex < totalPages && this.onPageChange(pageIndex+1)\">Next \u2192 </a></li>\n                            </ul>\n                          </div>\n                         </div>\n                         <div class=\"clearfix\">\n                       </div>\n                 </div>"
    }),
    __metadata("design:paramtypes", [router_1.Router, alertSummary_service_1.AlertSummaryService, core_1.ChangeDetectorRef])
], MonitoringView);
exports.MonitoringView = MonitoringView;
//# sourceMappingURL=monitoring.js.map