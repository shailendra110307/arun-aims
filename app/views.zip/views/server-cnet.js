"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var dataset_service_1 = require("../services/dataset-service");
var router_1 = require("@angular/router");
var alertSummary_service_1 = require("../services/alertSummary-service");
var eventSummary_service_1 = require("../services/eventSummary-service");
var applicationInfo_service_1 = require("../services/applicationInfo-service");
var containerSummary_service_1 = require("../services/containerSummary-service");
var diskutilitiesSummary_service_1 = require("../services/diskutilitiesSummary-service");
var ng2_daterangepicker_1 = require("ng2-daterangepicker");
var serverinfoSummary_model_1 = require("../model/serverinfoSummary-model");
var serverinfoSummary_service_1 = require("../services/serverinfoSummary-service");
var serverfactsInfo_model_1 = require("../model/serverfactsInfo-model");
var serverfactsInfo_service_1 = require("../services/serverfactsInfo-service");
var processdetailsInfo_model_1 = require("../model/processdetailsInfo-model");
var processdetailsInfo_service_1 = require("../services/processdetailsInfo-service");
var _ = require("lodash");
var d3 = require("d3");
var ServerComponent = (function () {
    function ServerComponent(router, alertSummaryService, eventSummaryService, applicationInfoService, containerSummaryService, diskutilitiesSummaryService, serverinfoSummaryService, serverfactsInfoService, ProcessdetailsInfoService, ref, datasetService) {
        var _this = this;
        this.router = router;
        this.alertSummaryService = alertSummaryService;
        this.eventSummaryService = eventSummaryService;
        this.applicationInfoService = applicationInfoService;
        this.containerSummaryService = containerSummaryService;
        this.diskutilitiesSummaryService = diskutilitiesSummaryService;
        this.serverinfoSummaryService = serverinfoSummaryService;
        this.serverfactsInfoService = serverfactsInfoService;
        this.ProcessdetailsInfoService = ProcessdetailsInfoService;
        this.ref = ref;
        this.datasetService = datasetService;
        this.currentTab = 'dashboard';
        this.categorical = [
            { "name": "schemeAccent", "n": 8 },
            { "name": "schemeDark2", "n": 8 },
            { "name": "schemePastel2", "n": 8 },
            { "name": "schemeSet2", "n": 8 },
            { "name": "schemeSet1", "n": 9 },
            { "name": "schemePastel1", "n": 9 },
            { "name": "schemeCategory10", "n": 10 },
            { "name": "schemeSet3", "n": 12 },
            { "name": "schemePaired", "n": 12 },
            { "name": "schemeCategory20", "n": 20 },
            { "name": "schemeCategory20b", "n": 20 },
            { "name": "schemeCategory20c", "n": 20 }
        ];
        this.curveArray = [
            { "d3Curve": d3.curveLinear, "curveTitle": "curveLinear" },
            { "d3Curve": d3.curveStep, "curveTitle": "curveStep" },
            { "d3Curve": d3.curveStepBefore, "curveTitle": "curveStepBefore" },
            { "d3Curve": d3.curveStepAfter, "curveTitle": "curveStepAfter" },
            { "d3Curve": d3.curveBasis, "curveTitle": "curveBasis" },
            { "d3Curve": d3.curveCardinal, "curveTitle": "curveCardinal" },
            { "d3Curve": d3.curveMonotoneX, "curveTitle": "curveMonotoneX" },
            { "d3Curve": d3.curveCatmullRom, "curveTitle": "curveCatmullRom" }
        ];
        this.areaOptions = {
            'backgroundColor': '#ffffff',
            'textSize': "12px",
            'textColor': '#000',
            'isLegend': true,
            'legendPosition': 'right',
            'isZoom': true,
            'xAxisLabel': 'value',
            'yAxisLabel': '',
            'dataColors': d3.scaleOrdinal().range(["rgba(0,136,191,0.8)", "rgba(152, 179, 74,0.8)", "rgba(246, 187, 66,0.8)", "#cc4748 ", "#cd82ad ", "#2f4074 ", "#448e4d ", "#b7b83f ", "#b9783f ", "#b93e3d ", "#913167 "]),
            'duration': 1000,
            'curve': this.curveArray[4].d3Curve
        };
        this.barOptions = {
            'backgroundColor': '#ffffff',
            'textSize': "12px",
            'textColor': '#000',
            'isLegend': true,
            'legendPosition': 'right',
            'isZoom': true,
            'xAxisLabel': '',
            'yAxisLabel': '',
            'dataColors': d3.scaleOrdinal().range(["rgba(0,136,191,0.8)", "rgba(152, 179, 74,0.8)", "rgba(246, 187, 66,0.8)", "#cc4748 ", "#cd82ad ", "#2f4074 ", "#448e4d ", "#b7b83f ", "#b9783f ", "#b93e3d ", "#913167 "]),
            'duration': 1000,
            'curve': this.curveArray[4].d3Curve
        };
        this.lineOptions = {
            'backgroundColor': '#ffffff',
            'textSize': "12px",
            'textColor': '#000',
            'isLegend': false,
            'legendPosition': 'right',
            'isZoom': true,
            'xAxisLabel': '',
            'yAxisLabel': '',
            'dataColors': d3.scaleOrdinal().range(["rgba(0,136,191,0.8)", "rgba(152, 179, 74,0.8)", "rgba(246, 187, 66,0.8)", "#cc4748 ", "#cd82ad ", "#2f4074 ", "#448e4d ", "#b7b83f ", "#b9783f ", "#b93e3d ", "#913167 "]),
            'duration': 1000,
            'curve': this.curveArray[0].d3Curve
        };
        this.lineOptions2 = {
            'backgroundColor': '#ffffff',
            'textSize': "12px",
            'textColor': '#000',
            'isLegend': true,
            'legendPosition': 'right',
            'isZoom': true,
            'xAxisLabel': 'Date',
            'yAxisLabel': 'Value',
            'dataColors': d3.scaleOrdinal().range(["rgba(0,136,191,0.8)", "rgba(152, 179, 74,0.8)", "rgba(246, 187, 66,0.8)", "#cc4748 ", "#cd82ad ", "#2f4074 ", "#448e4d ", "#b7b83f ", "#b9783f ", "#b93e3d ", "#913167 "]),
            'duration': 1000,
            'curve': this.curveArray[0].d3Curve
        };
        this.pieOptions = {
            'backgroundColor': '#fff',
            'textSize': "14px",
            'textColor': '#000',
            "padAngle": 0,
            "cornerRadius": 0,
            'isLegend': true,
            'legendPosition': 'right',
            'dataColors': d3.scaleOrdinal().range(["rgba(0,136,191,0.8)", "rgba(152, 179, 74,0.8)", "rgba(246, 187, 66,0.8)", "#cc4748 ", "#cd82ad ", "#2f4074 ", "#448e4d ", "#b7b83f ", "#b9783f ", "#b93e3d ", "#913167 "]),
            'duration': 1000,
            'innerRadiusDivider': 5.0,
            'outerRadiusDivider': 2.7,
            'labelRadiusDivider': 2.2
        };
        this.pieOptions2 = {
            'backgroundColor': '#fff',
            'textSize': "14px",
            'textColor': '#000',
            "padAngle": 0.05,
            "cornerRadius": 10,
            'isLegend': false,
            'legendPosition': 'right',
            'dataColors': d3.scaleOrdinal().range(["rgba(0,136,191,0.8)", "rgba(152, 179, 74,0.8)", "rgba(246, 187, 66,0.8)", "#cc4748 ", "#cd82ad ", "#2f4074 ", "#448e4d ", "#b7b83f ", "#b9783f ", "#b93e3d ", "#913167 "]),
            'duration': 1000,
            'innerRadiusDivider': 5.0,
            'outerRadiusDivider': 2.7,
            'labelRadiusDivider': 2.2
        };
        this.pieOptions3 = {
            'backgroundColor': '#ffffff',
            'textSize': "14px",
            'textColor': '#000',
            "padAngle": 0,
            "cornerRadius": 0,
            'isLegend': true,
            'legendPosition': 'right',
            'dataColors': d3.scaleOrdinal().range(["rgba(0,136,191,0.8)", "rgba(152, 179, 74,0.8)", "rgba(246, 187, 66,0.8)", "#cc4748 ", "#cd82ad ", "#2f4074 ", "#448e4d ", "#b7b83f ", "#b9783f ", "#b93e3d ", "#913167 "]),
            'duration': 1000,
            'innerRadiusDivider': 5.0,
            'outerRadiusDivider': 2.7,
            'labelRadiusDivider': 2.2
        };
        this.topologyOptions = {
            'backgroundColor': '#fff',
            'nodeTextSize': "14px",
            'nodeTextColor': '#000',
            'linkTextSize': "14px",
            'linkTextColor': '#000',
            // 'duration':1000,
            // 'strength': -500,//deprecated, less value => more distance between nodes, default -500
            'linkColor': "#555",
            'arrowColor': "#555",
            'nodeLabelField': "ip_address",
            'linkLabelField': null,
            'linkTooltioLabelFields': ["status", "nlq", "latency", "lq", "admin_state_up", "bitrate"],
            'nodeTooltipLabelFields': ["ip_address", "mac_address", "alerts"],
        };
        this.isWidget = false;
        this.pageIndex = 1;
        this.itemsPerPage = 5;
        router.events.subscribe(function (val) {
            if (val instanceof router_1.NavigationEnd) {
                if (_.startsWith(val.url, '/widget')) {
                    _this.isWidget = true;
                }
                else {
                    _this.isWidget = false;
                }
            }
        });
        debugger;
        console.log(this.router);
    }
    ServerComponent.prototype.onPageChange = function (newIndex) {
        this.pageIndex = newIndex;
        this.alertList = this.createPageChunk(this.initialAlertList);
        this.eventList = this.createPageChunk(this.initialEventList);
        this.applicationList = this.createPageChunk(this.initialApplicationlist);
        this.containerList = this.createPageChunk(this.initialContainerList);
        this.diskutilitiesList = this.createPageChunk(this.initialDiskutilitiesList);
        this.serverinfoList = this.createPageChunk(this.initialServerinfoList);
        this.serverfactsList = this.createPageChunk(this.initialServerfactsList);
        this.processdetailsList = this.createPageChunk(this.initialProcessdetailsList);
    };
    ServerComponent.prototype.callAlerts = function () {
        var _this = this;
        this.alertSummaryService.getAlertSummary().subscribe(function (data) {
            _this.pageIndex = 1;
            _this.initialAlertList = data;
            _this.alertList = _this.getAlertList(data["alerts"][0]);
        }, function () { return console.log('Finished'); });
    };
    ServerComponent.prototype.getAlertList = function (data) {
        var alerts = [];
        var alertsServer = [];
        var alertsApplication = [];
        for (var i = 0; i < data["server"].length; i++) {
            alerts.push(data["server"][i]);
            alertsServer.push(data["server"][i]);
        }
        for (var j = 0; j < data["application"].length; j++) {
            alerts.push(data["application"][j]);
            alertsApplication.push(data["application"][j]);
        }
        var count = 0;
        var length = alerts.length;
        var percentage;
        var statusclass;
        for (var i = 0; i < length; i++) {
            if (alerts[i].severity === "Critical") {
                count++;
            }
        }
        percentage = Math.round((count / length) * 100);
        if (percentage <= 33) {
            statusclass = 'severity-low';
        }
        else if (percentage >= 34 && percentage <= 66) {
            statusclass = 'severity-medium';
        }
        else {
            statusclass = 'severity-high';
        }
        this.alertsStatus = statusclass;
        return alerts;
    };
    ServerComponent.prototype.callEvents = function () {
        var _this = this;
        this.eventSummaryService.getEventSummary().subscribe(function (data) {
            _this.pageIndex = 1;
            _this.initialEventList = data;
            _this.eventList = _this.createPageChunk(data);
        }, function () { return console.log('Finished'); });
    };
    ServerComponent.prototype.callApplications = function () {
        var _this = this;
        this.applicationInfoService.getApplicationInfo().subscribe(function (data) {
            _this.pageIndex = 1;
            _this.initialApplicationlist = data;
            _this.applicationList = _this.createPageChunk(data);
        }, function () { return console.log('Finished'); });
    };
    ServerComponent.prototype.callContainers = function () {
        var _this = this;
        this.containerSummaryService.getContainerSummary().subscribe(function (data) {
            _this.pageIndex = 1;
            _this.initialContainerList = data;
            _this.containerList = _this.createPageChunk(data);
        }, function () { return console.log('Finished'); });
    };
    ServerComponent.prototype.callDiskutilitiess = function () {
        var _this = this;
        this.diskutilitiesSummaryService.getDiskutilitiesSummary().subscribe(function (data) {
            _this.pageIndex = 1;
            _this.initialDiskutilitiesList = data;
            _this.diskutilitiesList = _this.createPageChunk(data);
        }, function () { return console.log('Finished'); });
    };
    ServerComponent.prototype.callServerinfos = function () {
        var _this = this;
        this.serverinfoSummaryService.getServerinfoSummary().subscribe(function (data) {
            _this.pageIndex = 1;
            _this.initialServerinfoList = data;
            _this.serverinfoList = _this.createPageChunk(data);
        }, function () { return console.log('Finished'); });
    };
    ServerComponent.prototype.callServerfactss = function () {
        var _this = this;
        this.serverfactsInfoService.getServerfactsInfo().subscribe(function (data) {
            _this.pageIndex = 1;
            _this.initialServerfactsList = data;
            _this.serverfactsList = _this.createPageChunk(data);
        }, function () { return console.log('Finished'); });
    };
    ServerComponent.prototype.callProcessdetailss = function () {
        var _this = this;
        this.ProcessdetailsInfoService.getProcessdetailsInfo().subscribe(function (data) {
            _this.pageIndex = 1;
            _this.initialProcessdetailsList = data;
            _this.processdetailsList = _this.createPageChunk(data);
        }, function () { return console.log('Finished'); });
    };
    ServerComponent.prototype.createPageChunk = function (data) {
        this.totalPages = _.ceil(data.length / this.itemsPerPage);
        return _.chunk(data || [], this.itemsPerPage)[this.pageIndex - 1];
    };
    ServerComponent.prototype.onIPChange = function (filteredIPs) {
        this.pageIndex = 1;
        if (filteredIPs === undefined) {
            this.alertList = this.createPageChunk(this.initialAlertList);
        }
        else {
            this.alertList = this.createPageChunk(_.filter(this.initialAlertList || [], function (alert) {
                return _.includes(filteredIPs, alert.ip_address);
            }));
        }
    };
    ServerComponent.prototype.ngOnInit = function () {
        this.getAllData();
        this.callAlerts();
        this.callEvents();
        this.callApplications();
        this.callContainers();
        this.callDiskutilitiess();
        this.callServerinfos();
        this.callServerfactss();
        this.callProcessdetailss();
    };
    ServerComponent.prototype.changeTab = function (selectedTab) {
        if (this.currentTab !== selectedTab) {
            this.currentTab = selectedTab;
            this.getAllData();
        }
    };
    ServerComponent.prototype.getAllData = function () {
        this.datasetService.getServiceData();
        // this.datasetService.updatePieDataset();
        // this.datasetService.updateTopologyDataset();
    };
    return ServerComponent;
}());
ServerComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        templateUrl: 'server-cnet.html',
        providers: [dataset_service_1.DatasetService, serverinfoSummary_model_1.ServerinfoSummary, serverinfoSummary_service_1.ServerinfoSummaryService, processdetailsInfo_model_1.ProcessdetailsInfo, processdetailsInfo_service_1.ProcessdetailsInfoService, serverfactsInfo_model_1.ServerfactsInfo, serverfactsInfo_service_1.ServerfactsInfoService, ng2_daterangepicker_1.DaterangepickerConfig, alertSummary_service_1.AlertSummaryService, eventSummary_service_1.EventSummaryService, applicationInfo_service_1.ApplicationInfoService, containerSummary_service_1.ContainerSummaryService, diskutilitiesSummary_service_1.DiskutilitiesSummaryService]
    }),
    __metadata("design:paramtypes", [router_1.Router, alertSummary_service_1.AlertSummaryService,
        eventSummary_service_1.EventSummaryService,
        applicationInfo_service_1.ApplicationInfoService,
        containerSummary_service_1.ContainerSummaryService,
        diskutilitiesSummary_service_1.DiskutilitiesSummaryService,
        serverinfoSummary_service_1.ServerinfoSummaryService,
        serverfactsInfo_service_1.ServerfactsInfoService,
        processdetailsInfo_service_1.ProcessdetailsInfoService,
        core_1.ChangeDetectorRef, dataset_service_1.DatasetService])
], ServerComponent);
exports.ServerComponent = ServerComponent;
//# sourceMappingURL=server-cnet.js.map