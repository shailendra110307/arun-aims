"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var newService_service_1 = require("../services/newService-service");
var newService_model_1 = require("../model/newService-model");
var angular2_notifications_1 = require("angular2-notifications");
var router_1 = require("@angular/router");
var NewServiceView = (function () {
    function NewServiceView(newServiceInstance, notificationService, router) {
        this.newServiceInstance = newServiceInstance;
        this.notificationService = notificationService;
        this.router = router;
        this.options = {
            timeOut: 5000,
            lastOnBottom: true,
            clickToClose: true,
            maxLength: 0,
            maxStack: 7,
            showProgressBar: true,
            pauseOnHover: true,
            preventDuplicates: false,
            preventLastDuplicates: 'visible',
            rtl: false,
            animate: 'scale',
            position: ['right', 'bottom']
        };
        this.newServiceList = [];
        this.updatingIndex = 0;
    }
    NewServiceView.prototype.onSubmit = function () {
        var _this = this;
        this.newServiceInstance.postNewRequest(this.newServiceList)
            .subscribe(function (data) { return _this.router.navigateByUrl('/existing-infrastructure'); }, function (error) { return _this.notificationService.error('Failed', error); }, function () { return console.log('Finished'); });
    };
    NewServiceView.prototype.addRow = function () {
        var initialService = new newService_model_1.NewServiceModel();
        this.newServiceList.push(initialService);
        this.updatingIndex = (this.newServiceList.length - 1);
        this.showModal = true;
    };
    NewServiceView.prototype.edit = function (index) {
        this.updatingIndex = index;
        this.showModal = true;
    };
    NewServiceView.prototype.delete = function (index) {
        this.updatingIndex = index;
        this.newServiceList.splice(this.updatingIndex, 1);
    };
    NewServiceView.prototype.hideModal = function () {
        this.showModal = false;
    };
    return NewServiceView;
}());
NewServiceView = __decorate([
    core_1.Component({
        providers: [newService_service_1.NewService, angular2_notifications_1.NotificationsService],
        template: "<div class=\"box-content\">\n                 <h4 class=\"page-header\">New Service request</h4>\n                        <table class=\"table table-bordered table-striped table-hover table-heading table-datatable dataTable\" >\n                            <thead>\n                              <tr>\n                                <th>Service</th>\n                                <th>Version</th>\n                                <th>Action</th>\n                                <th>OS Details</th>\n                                <th>Release</th>\n                                <th>Options</th>\n                                <th>Options</th>\n                              </tr>\n                           </thead>\n                           <tfoot>\n                              <tr>\n                                <th>Service</th>\n                                <th>Version</th>\n                                <th>Action</th>\n                                <th>OS Details</th>\n                                <th>Release</th>\n                                <th>Options</th>\n                                <th>Options</th>\n                              </tr>\n                           </tfoot>\n                           <tbody>\n                            <tr *ngFor=\"let newService of newServiceList; let i=index\">\n                                <td>{{newService.service}}</td>\n                                <td>{{newService.version}}</td>\n                                <td>{{newService.action}}</td>\n                                <td>{{newService.os}}</td>\n                                <td>{{newService.release}}</td>\n                                <td><a (click)=\"edit(i)\">Edit/Details</a></td>\n                                <td><a (click)=\"delete(i)\">Delete</a></td>\n                             </tr>\n                           </tbody>\n                     </table>\n                     <div class=\"modal\" style=\"margin-top: 60px\" \n                      [ngClass]=\"{'show': showModal}\" id=\"myModal\" role=\"dialog\">\n                        <div class=\"modal-dialog\" role=\"document\">\n                          <div class=\"modal-content\">\n                            <div class=\"modal-header\">\n                              <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\" (click)=\"hideModal()\">\n                              <span aria-hidden=\"true\">&times;</span></button>\n                              <h4 class=\"modal-title\" id=\"myModalLabel\">New Service</h4>\n                            </div>\n                            <div class=\"modal-body\">\n                              <div class=\"form-group\" *ngIf=\"newServiceList.length\">\n                                   <label class=\"col-md-3 control-label\">Service Name</label>\n                                       <div class=\"col-md-3\">\n                                            <input type=\"text\" class=\"form-control\" [(ngModel)]=\"newServiceList[updatingIndex].service\" \n                                            name=\"service\"/>\n                                       </div>\n                                   <label class=\"col-md-3 control-label\">Version</label>\n                                       <div class=\"col-md-3\">\n                                            <input type=\"text\" class=\"form-control\" [(ngModel)]=\"newServiceList[updatingIndex].version\" \n                                            name=\"version\"/>\n                                       </div>\n                                   <label class=\"col-md-3 control-label\">Action</label>\n                                       <div class=\"col-md-3\">\n                                       <select class=\"populate placeholder form-control\" [(ngModel)]=\"newServiceList[updatingIndex].action\" \n                                       name=\"action\">\n                                            <option>Install</option>\n                                            <option>Uninstall</option>\n                                            <option>Pause</option>\n                                            <option>Shutdown</option>\n                                       </select>\n                                       </div>\n                                   <label class=\"col-md-3 control-label\">OS Details</label>\n                                       <div class=\"col-md-3\">\n                                            <input type=\"text\" class=\"form-control\" [(ngModel)]=\"newServiceList[updatingIndex].os\"\n                                             name=\"os\"/>\n                                       </div>\n                                   <label class=\"col-md-3 control-label\">Release</label>\n                                       <div class=\"col-md-3\">\n                                            <input type=\"text\" class=\"form-control\" [(ngModel)]=\"newServiceList[updatingIndex].release\"\n                                             name=\"release\"/>\n                                       </div>\n                                   <label class=\"col-md-3 control-label\">Package Type</label>\n                                       <div class=\"col-md-3\">\n                                            <input type=\"text\" class=\"form-control\" \n                                            [(ngModel)]=\"newServiceList[updatingIndex].license_info.package_type\" \n                                            name=\"package\"/>\n                                       </div>\n                                   <label class=\"col-md-3 control-label\">Issuer</label>\n                                       <div class=\"col-md-3\">\n                                            <input type=\"text\" class=\"form-control\" \n                                            [(ngModel)]=\"newServiceList[updatingIndex].license_info.issuer\" \n                                            name=\"issuer\"/>\n                                       </div>\n                                   <label class=\"col-md-3 control-label\">Key</label>\n                                       <div class=\"col-md-3\">\n                                            <input type=\"text\" class=\"form-control\" \n                                            [(ngModel)]=\"newServiceList[updatingIndex].license_info.key\" \n                                            name=\"key\"/>\n                                       </div>\n                                   <label class=\"col-md-3 control-label\">Start Date</label>\n                                       <div class=\"col-md-3\">\n                                            <input type=\"text\" class=\"form-control\"\n                                             [(ngModel)]=\"newServiceList[updatingIndex].license_info.start_date\" \n                                            name=\"startdate\"/>\n                                       </div>\n                                   <label class=\"col-md-3 control-label\">End Date</label>\n                                       <div class=\"col-md-3\">\n                                            <input type=\"text\" class=\"form-control\" \n                                            [(ngModel)]=\"newServiceList[updatingIndex].license_info.end_date\" \n                                            name=\"enddate\"/>\n                                       </div>\n                                   <label class=\"col-md-3 control-label\">Project</label>\n                                       <div class=\"col-md-3\">\n                                            <input type=\"text\" class=\"form-control\"\n                                             [(ngModel)]=\"newServiceList[updatingIndex].vm_info.project\" \n                                            name=\"project\"/>\n                                       </div>\n                                   <label class=\"col-md-3 control-label\">Role</label>\n                                       <div class=\"col-md-3\">\n                                            <input type=\"text\" class=\"form-control\"\n                                             [(ngModel)]=\"newServiceList[updatingIndex].vm_info.role\" \n                                            name=\"role\"/>\n                                       </div>\n                                   <label class=\"col-md-3 control-label\">VM List</label>\n                                       <div class=\"col-md-3\">\n                                            <input type=\"text\" class=\"form-control\"\n                                             [(ngModel)]=\"newServiceList[updatingIndex].vm_info.vm_list\" \n                                            name=\"vmlist\"/>\n                                       </div>\n                             </div>\n                            </div>\n                            <div class=\"modal-footer\">\n                              <button type=\"button\" class=\"btn btn-primary\" data-dismiss=\"modal\" (click)=\"hideModal()\">Close</button>\n                            </div>\n                          </div>\n                        </div>\n                      </div>\n                    <button (click)=\"addRow()\" class=\"btn btn-default btn-label\">Add New Service</button>\n                    <button (click)=\"onSubmit()\" class=\"btn btn-default btn-label\">Submit</button>\n                </div>"
    }),
    __metadata("design:paramtypes", [newService_service_1.NewService, angular2_notifications_1.NotificationsService,
        router_1.Router])
], NewServiceView);
exports.NewServiceView = NewServiceView;
//# sourceMappingURL=new-service.js.map