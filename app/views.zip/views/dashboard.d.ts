export declare class DashboardView {
}
