"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var logInsightGet_service_1 = require("../services/logInsightGet-service");
var _ = require("lodash");
var LogInsightView = (function () {
    function LogInsightView(router, route, logInsightGetService) {
        var _this = this;
        this.router = router;
        this.logInsightGetService = logInsightGetService;
        this.host = route.snapshot.params['host'];
        this.error_details = route.snapshot.params['error_details'];
        this.timestamp = route.snapshot.params['timestamp'];
        this.getLogList = [];
        this.isWidget = false;
        router.events.subscribe(function (val) {
            if (val instanceof router_1.NavigationEnd) {
                if (_.startsWith(val.url, '/widget')) {
                    _this.isWidget = true;
                }
                else {
                    _this.isWidget = false;
                }
            }
        });
    }
    LogInsightView.prototype.ngOnInit = function () {
        var _this = this;
        this.logInsightGetService.getLogInsight().subscribe(function (data) {
            _this.getLogList = data;
        }, function () { return console.log('Finished'); });
    };
    return LogInsightView;
}());
LogInsightView = __decorate([
    core_1.Component({
        providers: [logInsightGet_service_1.LogInsightGetService],
        template: "<div id=\"breadcrumb\" class=\"col-md-12\">\n                <ol class=\"breadcrumb\">\n                    <li><a [routerLink]=\"(isWidget ? '/widget-monitoring' : '/dashboard')\">Home</a></li>\n                    <li><a [routerLink]=\"(isWidget ? '/widget-monitoring' : '/monitoring')\">Monitoring</a></li>\n                    <li><a href=\"Javascript:void(0)\">Log Insight</a></li>\n                  </ol>\n              </div>\n              <div id=\"new-deployment-header\" class=\"row\">\n                <div class=\"col-md-12\"style=\"margin-left:5px;\">\n                  <h4>Log Insight</h4>\n                </div>\n              </div>\n             \n                <div class=\"container\">\n                 <table class=\"table table-bordered table-striped table-hover table-heading table-datatable dataTable\" >\n                   <thead>\n                        <tr>\n                          <th>Host</th>\n                          <th>Source</th>\n                          <th>Message</th>\n                          <th>Timestamp</th>\n                        </tr>\n                    </thead>\n                    <tbody>\n                      <tr *ngFor=\"let listItem of getLogList\">\n                          <td>{{listItem.host}}</td>\n                          <td>{{listItem.message}}</td>\n                          <td>{{listItem.source}}</td>\n                          <td>{{listItem.timestamp}}</td>\n                      </tr>\n                    </tbody>\n                    </table>\n                     <div class=\"box-content\">\n                      <div class=\"col-sm-6\">\n                       <div class=\"dataTables_info\" id=\"datatable-3_info\">Showing 1 to 10 entries</div></div>\n                         <div class=\"col-sm-6 text-right\">\n                          <div class=\"dataTables_paginate paging_bootstrap\">\n                            <ul class=\"pagination\">\n                            <li class=\"prev disabled\"><a href=\"#\">\u2190 Previous</a></li>\n                            <li class=\"active\"><a href=\"#\">1</a></li>\n                            <li class=\"next disabled\"><a href=\"#\">Next \u2192 </a></li>\n                            </ul>\n                          </div>\n                         </div>\n                         <div class=\"clearfix\">\n                         </div>\n                       </div>\n                  </div>"
    }),
    __metadata("design:paramtypes", [router_1.Router, router_1.ActivatedRoute, logInsightGet_service_1.LogInsightGetService])
], LogInsightView);
exports.LogInsightView = LogInsightView;
//# sourceMappingURL=log-insight.js.map