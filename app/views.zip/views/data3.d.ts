export declare const DATA3: {
    "timestamp": number;
    "errors": number;
}[];
