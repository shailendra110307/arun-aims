export declare const DATA2: {
    "timestamp": number;
    "upload": string;
    "download": string;
}[];
