"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var dataset_service_1 = require("../services/dataset-service");
var router_1 = require("@angular/router");
var eventSummary_service_1 = require("../services/eventSummary-service");
var ng2_daterangepicker_1 = require("ng2-daterangepicker");
var alertSummary_model_1 = require("../model/alertSummary-model");
var alertSummary_service_1 = require("../services/alertSummary-service");
var _ = require("lodash");
var d3 = require("d3");
var CnetMonitoringView = (function () {
    function CnetMonitoringView(router, alertSummaryService, ref, datasetService, eventSummaryService) {
        var _this = this;
        this.router = router;
        this.alertSummaryService = alertSummaryService;
        this.ref = ref;
        this.datasetService = datasetService;
        this.eventSummaryService = eventSummaryService;
        this.currentTab = 'overall';
        this.filter = new alertSummary_model_1.AlertSummary();
        this.totalWarning = 0;
        this.totalHigh = 0;
        this.totalCritical = 0;
        this.categorical = [
            { "name": "schemeAccent", "n": 8 },
            { "name": "schemeDark2", "n": 8 },
            { "name": "schemePastel2", "n": 8 },
            { "name": "schemeSet2", "n": 8 },
            { "name": "schemeSet1", "n": 9 },
            { "name": "schemePastel1", "n": 9 },
            { "name": "schemeCategory10", "n": 10 },
            { "name": "schemeSet3", "n": 12 },
            { "name": "schemePaired", "n": 12 },
            { "name": "schemeCategory20", "n": 20 },
            { "name": "schemeCategory20b", "n": 20 },
            { "name": "schemeCategory20c", "n": 20 }
        ];
        this.curveArray = [
            { "d3Curve": d3.curveLinear, "curveTitle": "curveLinear" },
            { "d3Curve": d3.curveStep, "curveTitle": "curveStep" },
            { "d3Curve": d3.curveStepBefore, "curveTitle": "curveStepBefore" },
            { "d3Curve": d3.curveStepAfter, "curveTitle": "curveStepAfter" },
            { "d3Curve": d3.curveBasis, "curveTitle": "curveBasis" },
            { "d3Curve": d3.curveCardinal, "curveTitle": "curveCardinal" },
            { "d3Curve": d3.curveMonotoneX, "curveTitle": "curveMonotoneX" },
            { "d3Curve": d3.curveCatmullRom, "curveTitle": "curveCatmullRom" }
        ];
        this.areaOptions = {
            'backgroundColor': '#ffffff',
            'textSize': "12px",
            'textColor': '#000',
            'isLegend': false,
            'legendPosition': 'right',
            'isZoom': true,
            'xAxisLabel': '',
            'yAxisLabel': '',
            'dataColors': d3.scaleOrdinal().range(["rgba(0,136,191,0.8)", "rgba(152, 179, 74,0.8)", "rgba(246, 187, 66,0.8)", "#cc4748 ", "#cd82ad ", "#2f4074 ", "#448e4d ", "#b7b83f ", "#b9783f ", "#b93e3d ", "#913167 "]),
            'duration': 1000,
            'curve': this.curveArray[4].d3Curve
        };
        this.barOptions = {
            'backgroundColor': '#ffffff',
            'textSize': "12px",
            'textColor': '#000',
            'isLegend': false,
            'legendPosition': 'right',
            'isZoom': true,
            'xAxisLabel': '',
            'yAxisLabel': '',
            'dataColors': d3.scaleOrdinal().range(["rgba(0,136,191,0.8)", "rgba(152, 179, 74,0.8)", "rgba(246, 187, 66,0.8)", "#cc4748 ", "#cd82ad ", "#2f4074 ", "#448e4d ", "#b7b83f ", "#b9783f ", "#b93e3d ", "#913167 "]),
            'duration': 1000,
            'curve': this.curveArray[4].d3Curve
        };
        this.lineOptions = {
            'backgroundColor': '#ffffff',
            'textSize': "12px",
            'textColor': '#000',
            'isLegend': false,
            'legendPosition': 'right',
            'isZoom': true,
            'xAxisLabel': '',
            'yAxisLabel': '',
            'dataColors': d3.scaleOrdinal().range(["rgba(0,136,191,0.8)", "rgba(152, 179, 74,0.8)", "rgba(246, 187, 66,0.8)", "#cc4748 ", "#cd82ad ", "#2f4074 ", "#448e4d ", "#b7b83f ", "#b9783f ", "#b93e3d ", "#913167 "]),
            'duration': 1000,
            'curve': this.curveArray[0].d3Curve
        };
        this.lineOptions2 = {
            'backgroundColor': '#ffffff',
            'textSize': "12px",
            'textColor': '#000',
            'isLegend': false,
            'legendPosition': 'right',
            'isZoom': true,
            'xAxisLabel': 'Date',
            'yAxisLabel': 'Value',
            'dataColors': d3.scaleOrdinal().range(["rgba(0,136,191,0.8)", "rgba(152, 179, 74,0.8)", "rgba(246, 187, 66,0.8)", "#cc4748 ", "#cd82ad ", "#2f4074 ", "#448e4d ", "#b7b83f ", "#b9783f ", "#b93e3d ", "#913167 "]),
            'duration': 1000,
            'curve': this.curveArray[0].d3Curve
        };
        this.pieOptions = {
            'backgroundColor': '#fff',
            'textSize': "14px",
            'textColor': '#000',
            "padAngle": 0,
            "cornerRadius": 0,
            'isLegend': true,
            'legendPosition': 'right',
            'dataColors': d3.scaleOrdinal().range(["rgba(0,136,191,0.8)", "rgba(152, 179, 74,0.8)", "rgba(246, 187, 66,0.8)", "#cc4748 ", "#cd82ad ", "#2f4074 ", "#448e4d ", "#b7b83f ", "#b9783f ", "#b93e3d ", "#913167 "]),
            'duration': 1000,
            'innerRadiusDivider': 5.0,
            'outerRadiusDivider': 2.7,
            'labelRadiusDivider': 2.2
        };
        this.pieOptions2 = {
            'backgroundColor': '#fff',
            'textSize': "14px",
            'textColor': '#000',
            "padAngle": 0.05,
            "cornerRadius": 10,
            'isLegend': false,
            'legendPosition': 'right',
            'dataColors': d3.scaleOrdinal().range(["rgba(0,136,191,0.8)", "rgba(152, 179, 74,0.8)", "rgba(246, 187, 66,0.8)", "#cc4748 ", "#cd82ad ", "#2f4074 ", "#448e4d ", "#b7b83f ", "#b9783f ", "#b93e3d ", "#913167 "]),
            'duration': 1000,
            'innerRadiusDivider': 5.0,
            'outerRadiusDivider': 2.7,
            'labelRadiusDivider': 2.2
        };
        this.pieOptions3 = {
            'backgroundColor': '#ffffff',
            'textSize': "14px",
            'textColor': '#000',
            "padAngle": 0,
            "cornerRadius": 0,
            'isLegend': true,
            'legendPosition': 'right',
            'dataColors': d3.scaleOrdinal().range(["rgba(0,136,191,0.8)", "rgba(152, 179, 74,0.8)", "rgba(246, 187, 66,0.8)", "#cc4748 ", "#cd82ad ", "#2f4074 ", "#448e4d ", "#b7b83f ", "#b9783f ", "#b93e3d ", "#913167 "]),
            'duration': 1000,
            'innerRadiusDivider': 5.0,
            'outerRadiusDivider': 2.7,
            'labelRadiusDivider': 2.2
        };
        this.topologyOptions = {
            'backgroundColor': '#ffffff',
            'nodeTextSize': "14px",
            'nodeTextColor': '#000',
            'linkTextSize': "14px",
            'linkTextColor': '#000',
            'duration': 1000,
            'strength': -5000,
            'linkColor': "#555",
            'arrowColor': "#555",
            'nodeLabelField': "ip_address",
            'linkLabelField': "bitrate",
            'linkTooltioLabelFields': ["status", "nlq", "latency", "lq", "admin_state_up", "bitrate"],
            'nodeTooltipLabelFields': ["ip_address", "mac_address", "alerts"]
        };
        this.isWidget = false;
        this.pageIndex = 1;
        this.itemsPerPage = 5;
        router.events.subscribe(function (val) {
            if (val instanceof router_1.NavigationEnd) {
                if (_.startsWith(val.url, '/widget')) {
                    _this.isWidget = true;
                }
                else {
                    _this.isWidget = false;
                }
            }
        });
    }
    CnetMonitoringView.prototype.ngOnInit = function () {
        this.getAllData();
        this.callAlerts();
        this.callEvents();
    };
    // onPageChange(newIndex: number) {
    //     this.pageIndex = newIndex;
    //     this.alertList = this.createPageChunk(this.initialAlertList);
    // }
    CnetMonitoringView.prototype.callEvents = function () {
        var _this = this;
        this.eventSummaryService.getEventSummary().subscribe(function (data) {
            _this.pageIndex = 1;
            _this.initialEventList = data;
            _this.eventList = _this.createPageChunk(data);
        }, function () { return console.log('Finished'); });
    };
    CnetMonitoringView.prototype.callAlerts = function () {
        var _this = this;
        this.alertSummaryService.getAlertSummary().subscribe(function (data) {
            _this.pageIndex = 1;
            _this.initialAlertList = data;
            _this.alertList = _this.getAlertList(data["alerts"][0]);
        }, function () { return console.log('Finished'); });
    };
    CnetMonitoringView.prototype.createPageChunk = function (data) {
        if (data) {
            this.totalPages = _.ceil(data.length / this.itemsPerPage);
            return _.chunk(data || [], this.itemsPerPage)[this.pageIndex - 1];
        }
        return null;
    };
    CnetMonitoringView.prototype.getAlertList = function (data) {
        var alerts = [];
        var alertsServer = [];
        var alertsApplication = [];
        for (var i = 0; i < data["server"].length; i++) {
            alerts.push(data["server"][i]);
            alertsServer.push(data["server"][i]);
        }
        for (var j = 0; j < data["application"].length; j++) {
            alerts.push(data["application"][j]);
            alertsApplication.push(data["application"][j]);
        }
        var length = alerts.length;
        for (var i = 0; i < length; i++) {
            if (alerts[i].severity === "Warning") {
                this.totalWarning++;
            }
            if (alerts[i].severity === "High") {
                this.totalHigh++;
            }
            if (alerts[i].severity === "Critical") {
                this.totalCritical++;
            }
        }
        this.totalAlerts = alerts.length;
        this.alertsServer = alertsServer;
        this.alertsApplication = alertsApplication;
        return alerts;
    };
    CnetMonitoringView.prototype.changeTab = function (selectedTab) {
        if (this.currentTab !== selectedTab) {
            this.currentTab = selectedTab;
            //this.getAllData();
        }
    };
    CnetMonitoringView.prototype.getAllData = function () {
        this.datasetService.getServiceData();
    };
    CnetMonitoringView.prototype.onIPChange = function (filteredIPs) {
        // this.pageIndex = 1;
        // if (filteredIPs === undefined) {
        //     this.alertList = this.createPageChunk(this.initialAlertList);
        // } else {
        //     this.alertList = this.createPageChunk(_.filter(this.initialAlertList || [], function (alert) {
        //         return _.includes(filteredIPs, alert.ip_address);
        //     }));
        // }
    };
    return CnetMonitoringView;
}());
CnetMonitoringView = __decorate([
    core_1.Component({
        moduleId: module.id,
        templateUrl: 'monitoring-cnet.html',
        styleUrls: ['monitoring-cnet.css'],
        providers: [dataset_service_1.DatasetService, ng2_daterangepicker_1.DaterangepickerConfig, alertSummary_service_1.AlertSummaryService, eventSummary_service_1.EventSummaryService]
    }),
    __metadata("design:paramtypes", [router_1.Router, alertSummary_service_1.AlertSummaryService,
        core_1.ChangeDetectorRef, dataset_service_1.DatasetService, eventSummary_service_1.EventSummaryService])
], CnetMonitoringView);
exports.CnetMonitoringView = CnetMonitoringView;
//# sourceMappingURL=monitoring-cnet.js.map